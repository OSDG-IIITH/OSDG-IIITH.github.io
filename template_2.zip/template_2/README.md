# osdg-website-design-2
2nd iteration of OSDG site
