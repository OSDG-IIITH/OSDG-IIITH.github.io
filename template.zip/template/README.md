# osdg-website-design-1

Jekyll based OSDG website design

## Installation

Install Jekyll from [here](https://jekyllrb.com/docs/installation/).

## Execution

Clone the repo.
Open the osdg-website-design-1
Run the following command:
```bash
jekyll serve
```
